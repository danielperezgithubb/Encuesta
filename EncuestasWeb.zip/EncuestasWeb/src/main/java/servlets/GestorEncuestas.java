package servlets;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Servlet implementation class GestorEncuestas
 */
@WebServlet("/gestion")
public class GestorEncuestas extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	// Inicializamos el ArrayList en el contexto de aplicación
    @Override
    public void init() throws ServletException {
        // Crear la colección de encuestas y guardarla en el contexto de la aplicación
        ServletContext context = getServletContext();
        ArrayList<Encuesta> encuestas;
       	encuestas = new ArrayList<Encuesta>();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	RequestDispatcher rd = request.getRequestDispatcher("/encuestas.jsp");
    	rd.forward(request, response);
    	
   
    }
    
   
}